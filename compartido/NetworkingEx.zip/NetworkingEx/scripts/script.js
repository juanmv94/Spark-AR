const Diagnostics = require('Diagnostics');
const Networking = require('Networking');
export const Scene = require('Scene');

const url = 'https://api.ipify.org?format=json';

const request = {
  method: 'GET',
  //headers: {'Content-type': 'application/json; charset=UTF-8'},
  //body: JSON.stringify({title: 'Networking Module'})
};

Networking.fetch(url, request).then(function(result) {
  if ((result.status >= 200) && (result.status < 300)) {
    result.json().then(function(json) {
		Diagnostics.log(json);
		Scene.root.findFirst("2dText0").then(function(t) {
			t.text=json.ip;
		});
	});
  }
}).catch(function(error) {
  Diagnostics.log(error);
});